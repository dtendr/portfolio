#pragma once



class Graphics_Object
{
};